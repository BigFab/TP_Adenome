
library(rJava)
library(ggplot2)
library(corrplot)
library(cluster)
library(reshape2)
library(factoextra)
library(xlsx)
library(dtw)
library(rpart.plot)
library(rpart)
theme_set(theme_classic())

#On crée des fonctions pour faires des barplots et boxplots tout au long du projet.
adenome_boxplot <- function(df, feature_index, title){
  x_axis = colnames(df)[feature_index]

  g <- ggplot(df, aes("", df[,feature_index]))
  g <- g + geom_boxplot(varwidth=T, fill="plum")
  g <- g + labs(title=title, 
         subtitle=x_axis,
         x=x_axis,
         y="")
  print(g)
}

adenome_boxplot_couple <- function(df, feature_1, feature_2, f1, f2){
  x_axis = f1
  y_axis = f2
  title = paste(x_axis, " Vs. ", y_axis)
    
  g <- ggplot(df, aes(x = feature_1, y = feature_2))
  g <- g + geom_boxplot(varwidth=T, fill="plum")
  g <- g + labs(title=title, 
         subtitle="",
         x=x_axis,
         y=y_axis)
    
  print(g)
}

adenome_scatterplot <- function(df, feature_1, feature_2, f1, f2) {
  x_axis = f1
  y_axis = f2
  title = "VAPOR"
  subtitle = paste(x_axis, " Vs. ", y_axis)
  g <- ggplot(df, aes(x=feature_1, y=feature_2))
  g <- g + geom_point()
  g <- g + labs(title=title,y=y_axis,x=x_axis)
  print(g)
}

adenome_barplot <- function(df, feature_index, title) {
  x_axis = colnames(df)[feature_index]
  g <- ggplot(df, aes(df[,feature_index]))
  g <- g + geom_bar(width = 0.15,fill = c("#FF6666"))+theme_bw()
  g <- g + labs(title=title, 
         subtitle=x_axis,
         x=x_axis,
         y="")
  print(g)
}

adenome_piechart <- function(df, feature_index, title){
  bar <- ggplot(vapor, aes(x="", fill = factor(df[,feature_index]))) + geom_bar(width = 1)
  pie <- bar + coord_polar(theta = "y")
  print(pie)
}

# Obtenir le triangle inférieur d'une matrice
get_lower_tri <- function(mat){
    mat[upper.tri(mat)] <- NA
    return(mat)
}

# Obtenir le triangle supérieur d'une matrice
get_upper_tri <- function(mat){
    mat[lower.tri(mat)] <- NA
    return(mat)
}

# Re-ordonne la matrice de corrélation
reorder_cormat <- function(cormat){
    # Utiliser la corrélation entre les variables
    # comme mesure de distance
    dd <- as.dist((1-cormat)/2)
    hc <- hclust(dd)
    cormat <- cormat[hc$order, hc$order]
}

adenome_heatmap <- function(cormat) { 
    # Reordonner la matrice de corrélation
    cormat <- reorder_cormat(cormat)
    upper_tri <- get_upper_tri(cormat)
    # Fondre la matrice de corrélation
    melted_cormat <- melt(upper_tri, na.rm = TRUE)
    # Créer le heatmap
    ggheatmap <- ggplot(melted_cormat, aes(Var2, Var1, fill = value))+
        geom_tile(color = "white")+
        scale_fill_gradient2(low = "blue", high = "red", mid = "white", 
        midpoint = 0, limit = c(-1,1), space = "Lab",
        name="Pearson\nCorrelation") +
        theme_minimal()+ # minimal theme
        theme(axis.text.x = element_text(angle = 45, vjust = 1, 
        size = 12, hjust = 1))+
        coord_fixed()
    
ggheatmap <- ggheatmap + 
    geom_text(aes(Var2, Var1, label = round(value,3)), color = "black", size = 3) +
    theme(
      axis.title.x = element_blank(),
      axis.title.y = element_blank(),
      panel.grid.major = element_blank(),
      panel.border = element_blank(),
      panel.background = element_blank(),
      axis.ticks = element_blank(),
      legend.justification = c(1, 0),
      legend.position = c(0.6, 0.7),
      legend.direction = "horizontal")+
      guides(fill = guide_colorbar(barwidth = 7, barheight = 1,
                title.position = "top", title.hjust = 0.5))
    
    # Afficher heatmap
    print(ggheatmap)
}

# import du fichier complet
vapor <- read.xlsx(file = "datasets/VAPOR.xlsx", sheetIndex = 1, header = 1, startRow = 2)[,-1]
attributes(vapor)$names = c('Age','Comorbidite','Duree_Traitement_Medical','Porteur_Sonde','IPSS','QoL','Qmax','PSA','Volume_Prostatique','Residu_post_mictionnel','Indication','Anesthesie','Evenement','Technique','Transfusion','Temps_Operation','Volume_Reseque','Delai_Ablation','Caillotage','Reprise_Bloc',
    'X1M_IPSS','X1M_QoL','X1M_Qmax','X3M_IPSS','X3M_QoL','X3M_Qmax','X6M_IPSS','X6M_QoL','X6M_Qmax','X9M_IPSS','X9M_QoL','X9M_Qmax','X12M_IPSS','X12M_QoL','X12M_Qmax','X15M_IPSS','X15M_QoL','X15M_Qmax','X18M_IPSS','X18M_QoL','X18M_Qmax')

# Cast des variables booléennes
vapor$Comorbidite<-as.logical(vapor$Comorbidite)
vapor$Porteur_Sonde<-as.logical(vapor$Porteur_Sonde)
vapor$Transfusion<-as.logical(vapor$Transfusion)
vapor$Caillotage<-as.logical(vapor$Caillotage)
vapor$Reprise_Bloc<-as.logical(vapor$Reprise_Bloc)

# Cast des variables catégoriques
vapor$Indication<-as.factor(vapor$Indication)
vapor$Anesthesie<-as.factor(vapor$Anesthesie)
vapor$Evenement<-as.factor(vapor$Evenement)
vapor$Technique<-as.factor(vapor$Technique)

# Cast des variables catégoriques ordonnées
vapor$QoL<-as.ordered(vapor$QoL)
vapor$X1M_QoL<-as.ordered(vapor$X1M_QoL)
vapor$X3M_QoL<-as.ordered(vapor$X3M_QoL)
vapor$X6M_QoL<-as.ordered(vapor$X6M_QoL)
vapor$X9M_QoL<-as.ordered(vapor$X9M_QoL)
vapor$X12M_QoL<-as.ordered(vapor$X12M_QoL)
vapor$X15M_QoL<-as.ordered(vapor$X15M_QoL)
vapor$X18M_QoL<-as.ordered(vapor$X18M_QoL)
# 20 premières colonnes du dataset -> pré-opératoire et les dernières -> post-opératoire
vapor_pre<-vapor[,1:20]
vapor_post<-vapor[,21:41]

# On crée un dataframe ne comportant que les variables numériques (pour corrélation linéaire de Pearson)
vapor_num <- vapor[,sapply(vapor, function(x) is.numeric(x))]
vapor_num_pre = vapor_num[1:10]
vapor_num_post = vapor_num[11:24]


#Faut il garder le résidu post  ou l'enlever ? 
#On enlève tout les individus ayant un résidu post mictionnel=NA
vapor_num_pre_sans= subset(vapor_num_pre[which(vapor_num_pre$Residu_post_mictionnel != ""),])

mat_cor_vapoor_num_pre = cor(vapor_num_pre_sans, method = c("pearson"))
adenome_heatmap(mat_cor_vapoor_num_pre )
   


pca <- stats::prcomp(x=subset(vapor_num_pre_sans))
pca

# Quelques distributions par rapport aux porteurs de sondes
boxplot(vapor_pre[which(vapor_pre$Porteur_Sonde == 1),'Residu_post_mictionnel'], vapor_pre[which(vapor_pre$Porteur_Sonde == 0),'Residu_post_mictionnel'], names=c("Porteur","Sans sonde"),horizontal=TRUE,main="VAPOR - Pré-opératoire\n(Résidu post mictionnel selon sonde)", col=c("blue","red"))
boxplot(vapor_pre[which(vapor_pre$Porteur_Sonde == 1),'Age'], vapor_pre[which(vapor_pre$Porteur_Sonde == 0),'Age'], names=c("Porteur","Sans sonde"),horizontal=TRUE,main="VAPOR - Pré-opératoire\n(Age selon sonde)", col=c("blue","red"))
boxplot(vapor_pre[which(vapor_pre$Porteur_Sonde == 1),'Duree_Traitement_Medical'], vapor_pre[which(vapor_pre$Porteur_Sonde == 0),'Duree_Traitement_Medical'], names=c("Porteur","Sans sonde"),horizontal=TRUE,main="VAPOR - Pré-opératoire\n(Durée traitement selon sonde)", col=c("blue","red"))


vapor=vapor[which(vapor$Porteur_Sonde == FALSE),]
vapor= subset(vapor,select=-c(Porteur_Sonde,Technique))
# 20 premières colonnes du dataset sont donnees pré-opératoire et les dernièrespost-opératoire
vapor_pre<-vapor[,1:18]
vapor_post<-vapor[,19:39]
# On crée un dataframe ne comportant que les variables numériques (pour corrélation linéaire de Pearson)
vapor_num <- vapor[,sapply(vapor, function(x) is.numeric(x))]
vapor_num_pre = vapor_num[1:10]
vapor_num_post = vapor_num[11:24]

# On crée un dataframe ne comportant que les données booléennes, ordinales ou catégoriques
vapor_cat <- vapor[,sapply(vapor, function(x) is.ordered(x) | is.factor(x) | is.logical(x))]
vapor_cat = subset(vapor,select=c(Comorbidite,QoL,Indication,Evenement,Anesthesie,Transfusion,Caillotage,Reprise_Bloc,X1M_QoL,X3M_QoL,X6M_QoL,X9M_QoL,X12M_QoL,X15M_QoL,X18M_QoL))
vapor_cat_pre = vapor_cat[1:8]
vapor_cat_post = vapor_cat[9:15]

# Barplots des variables catégoriques
fill <- c("#d3d3d3", "#a8a8a8", "#7e7e7e", "#545454", "#2a2a2a")

for (i in 1:ncol(vapor_pre)) {
    # Boxplots des variables numériques
    if (is.numeric(vapor_pre[,i]))
        boxplot(vapor_pre[,i],
            names=c("VAPOR"),horizontal=TRUE,main=paste("VAPOR - Pré-opératoire\n(", colnames(vapor_pre)[i],")"), col=c("blue","red","#009900"))
    else {
        adenome_barplot(vapor_pre,i,"VAPOR Pre-operatoire")
    }
}

mat_cor_vapor_num_pre = cor(vapor_num_pre, method = c("pearson"))
adenome_heatmap(mat_cor_vapor_num_pre)

adenome_scatterplot(vapor_pre,vapor_pre$Volume_Prostatique,vapor_pre$Volume_Reseque,"Volume_Prostatique","Volume_Reseque")
adenome_scatterplot(vapor_pre,vapor_pre$Qmax,vapor_pre$IPSS,"Qmax","IPSS")
adenome_scatterplot(vapor_pre,vapor_pre$Volume_Prostatique,vapor_pre$Temps_Operation,"Volume_Prostatique","Tmps_OP")
adenome_scatterplot(vapor_pre,vapor_pre$Delai_Ablation,vapor_pre$Volume_Prostatique,"Delai_ablation","Volume_Prostatique")

pca <- stats::prcomp(x=subset(vapor_num_pre))
summary(pca)

sum(100 * (pca$sdev^2)[1:3] / sum(pca$sdev^2))

library(factoextra)
fviz_eig(pca, addlabels = TRUE, ylim = c(0, 50))

library("factoextra")
fviz_pca_var(pca, col.var = "contrib",
             gradient.cols = c("#00AFBB", "#E7B800", "#FC4E07"),
             repel = TRUE # Évite le chevauchement de texte
             )

#On choisit trois individus au hazard
require(graphics)
individu= sample(1:nrow(vapor_num_post), 3)
i1=individu[1]
i2=individu[2]
i3=individu[3]
#On crée des séries temporels pour nos variable Q_max ,IPSS et QoL
vapor_num_post_qmax=t(subset(vapor_num_post,select=c(X1M_Qmax,X3M_Qmax,X6M_Qmax,X9M_Qmax,X12M_Qmax,X15M_Qmax,X18M_Qmax)))
vapor_num_post_ipss=t(subset(vapor_num_post,select=c(X1M_IPSS,X3M_IPSS,X6M_IPSS,X9M_IPSS,X12M_IPSS,X15M_IPSS,X18M_IPSS)))
vapor_cat_post_QoL=t(vapor_cat_post)
vapor_num_post_series_qmax=ts(vapor_num_post_qmax, start=1,deltat=3)
vapor_num_post_series_ipss=ts(vapor_num_post_ipss, start=1,deltat=3)
vapor_cat_post_series_QoL=ts(vapor_cat_post_QoL, start=1,deltat=3)

#On plot l'évolution de Q_max pour les 3 individus tirés au sort
Q_max_Individu1=vapor_num_post_series_qmax[,i1]
Q_max_Individu2=vapor_num_post_series_qmax[,i2]
Q_max_Individu3=vapor_num_post_series_qmax[,i3]
Q_max=cbind(Q_max_Individu1,Q_max_Individu2,Q_max_Individu3)
ts.plot(Q_max,gpars= list(col=rainbow(3)),xlab="Nombre de mois",ylab= "Q_max",main="Représentation de l'évolution de Q_max pour différents individus")

#On plot l'évolution de IPSS pour les 3 individus tirés au sort
Ipss_Individu1=vapor_num_post_series_ipss[,i1]
Ipss_Individu2=vapor_num_post_series_ipss[,i2]
Ipss_Individu3=vapor_num_post_series_ipss[,i3]
Ipss=cbind(Ipss_Individu1,Ipss_Individu2,Ipss_Individu3)
ts.plot(Ipss,gpars= list(col=rainbow(3)),ylab= "IPSS",xlab="Nombre de mois",main="Représentation de l'évolution de IPSS pour différents individus")


#On plot l'évolution de Qol pour les 3 individus tirés au sort
QoL_Individu1=vapor_cat_post_series_QoL[,i1]
QoL_Individu2=vapor_cat_post_series_QoL[,i2]
QoL_Individu3=vapor_cat_post_series_QoL[,i3]
QoL=cbind(QoL_Individu1,QoL_Individu2,QoL_Individu3)
ts.plot(QoL,gpars= list(col=rainbow(3)),xlab="Nombre de mois",ylab= "QoL",main="Représentation de l'évolution de QoL pour différents individus")



#On trace l'évolution de QMax en fonction du temps
Boxplot=matrix(NA,nrow=nrow(vapor_num_post),ncol=2)
for (i in 1:nrow(Boxplot)){
    Boxplot[i,2]=vapor_num_post$X1M_Qmax[i]
    Boxplot[i,1]=1
}
Boxplot2=matrix(NA,nrow=nrow(vapor_num_post),ncol=2)
Qmax=subset(vapor_num_post,select=c(X3M_Qmax,X6M_Qmax,X9M_Qmax,X12M_Qmax,X15M_Qmax,X18M_Qmax))
for (i in 1:ncol(Qmax)){
for (k in 1:nrow(Boxplot2)){
    Boxplot2[k,2]=Qmax[k,i]
    Boxplot2[k,1]=i*3
}
Boxplot=rbind(Boxplot,Boxplot2)
}
boxplot(Boxplot[,2]~Boxplot[,1], main="Représentation de l'évolution de Q_max en fonction du temps", col=6 ,xlab="Nombre de mois", ylab="Valeur de Q_max")

#On trace l'évolution d'IPSS en fonction du temps
Boxplot=matrix(NA,nrow=nrow(vapor_num_post),ncol=2)
for (i in 1:nrow(Boxplot)){
    Boxplot[i,2]=vapor_num_post$X1M_IPSS[i]
    Boxplot[i,1]=1
}
Boxplot2=matrix(NA,nrow=nrow(vapor_num_post),ncol=2)
ipss=subset(vapor_num_post,select=c(X3M_IPSS,X6M_IPSS,X9M_IPSS,X12M_IPSS,X15M_IPSS,X18M_IPSS))
for (i in 1:ncol(ipss)){
for (k in 1:nrow(Boxplot2)){
    Boxplot2[k,2]=ipss[k,i]
    Boxplot2[k,1]=i*3
}
Boxplot=rbind(Boxplot,Boxplot2)
}
boxplot(Boxplot[,2]~Boxplot[,1], main="Représentation de l'évolution de IPSS en fonction du temps", col=6 ,xlab="Nombre de mois", ylab="Valeur de IPSS")


#On trace l'évolution de QoL en fonction du temps
Boxplot=matrix(NA,nrow=nrow(vapor_num_post),ncol=2)
for (i in 1:nrow(Boxplot)){
    Boxplot[i,2]=vapor_cat_post$X1M_QoL[i]
    Boxplot[i,1]=1
}
Boxplot2=matrix(NA,nrow=nrow(vapor_num_post),ncol=2)
QoL=subset(vapor_cat_post,select=-c(X1M_QoL))
for (i in 1:ncol(QoL)){
for (k in 1:nrow(Boxplot2)){
    Boxplot2[k,2]=QoL[k,i]
    Boxplot2[k,1]=i*3
}
Boxplot=rbind(Boxplot,Boxplot2)
}
boxplot(Boxplot[,2]~Boxplot[,1], main="Représentation de l'évolution de QoL en fonction du temps", col=6 ,xlab="Nombre de mois", ylab="Valeur de QoL")


require(cluster)
library(fpc)
#On crée notre matrice de dissimilarité utilisant daisy car matrice hétérogène
disMatrix_pre=daisy(vapor_pre,metric = c("gower"))
cmd=cmdscale(disMatrix_pre,k=2)
plot(cmd[,1],cmd[,2],main="Cmdscale sur la matrice de dissimilarité",xlab="Composante1",ylab="Composante2")

#On fait une boucle pour repèrer les 5 meilleurs valeurs de k qui maximise la valeur silhouette
respam<- numeric(20)
for (k in 2:20)
respam[[k]] <- pam(disMatrix_pre,k) $ silinfo $ avg.width
sortrespam=respam[which(respam>0.7)]
sortrespam=sort(sortrespam,decreasing=TRUE)
k.best=c()
for (i in 1:length(sortrespam)){
        k.best[i] <-which(respam[]==sortrespam[i])
}
#On regarde le min de k pour une valeur silhouette supérieur à 0.7
k.min<-min(k.best)
cat("Les 5 meilleurs nombre de clusters sont", k.best[1:5], ". Ayant une valeur silhouette de ",respam[k.best[1:5]],". Le nombre de cluster pour une valeur silhouette maximale est=" ,k.best[1]," . \n")
cat("Le nombre minimal de clusters pour une valeur silhouette supérieure à 0.7 est", k.min, " et ayant un valeur silhouette de ",respam[k.min],"\n")

k.optimal_pre=k.min

library(fpc)
respam_optimal_pre=pam(disMatrix_pre,k.optimal_pre)
plot(respam_optimal_pre)
vapor_pre_sans_res_num=subset(vapor_num_pre[which(vapor_num_pre$Residu_post_mictionnel != ""),])
clusplot(vapor_num_pre, respam_optimal_pre$clustering, labels=2, lines=0)

resuhc <- hclust(disMatrix_pre, method = "ward.D2")
# Visualization de resuhc
plot(resuhc, labels = FALSE, hang = -1)
# Ajout des rectangles autour des clusters
rect.hclust(resuhc, k =k.optimal_pre, border = 2:4) 

#Indication des médoids
medoid_pre=c()
respam_optimal_pre=pam(disMatrix_pre,k=k.optimal_pre)
medoids_pre=respam_optimal_pre$medoids
for (i in 1:length(medoids_pre)){
   medoid_pre=rbind(medoid_pre,vapor_pre[medoids_pre[i],])
    }
medoid_pre

clusters=respam_optimal_pre$clustering
Boxplot2=matrix(NA,ncol=2,nrow=10)
for(i in 1:6){
    clust=vapor_num_post$X12M_Qmax[which(clusters==i)]
    for (j in 1:length(clust)){
       Boxplot2[j,2]=clust[j]
        Boxplot2[j,1]=i
}
Boxplot2=rbind(Boxplot2,Boxplot2)
}

boxplot(Boxplot2[,2]~Boxplot2[,1], main="Représentation de la distribution de Qmax en fonction des classes", col=(c("gold","darkgreen","darkblue","red","blue")), ,xlab="Numéro de la classe", ylab="Valeur de Qmax 12 mois")

clusters=respam_optimal_pre$clustering
for(i in 1:k.optimal_pre){
    clust=which(clusters==i)
    boxplot(vapor_post[clust,15],
            names=c("VAPOR"),horizontal=TRUE,main=paste("VAPOR - Pré-opératoire\n(cluster", i, ")"), col=c("blue","red","#009900"))
    
    }

#On crée une matrice de séries temporelles
vapor_cat_post$X1M_QoL<-as.numeric(vapor_cat_post$X1M_QoL)
vapor_cat_post$X3M_QoL<-as.numeric(vapor_cat_post$X3M_QoL)
vapor_cat_post$X6M_QoL<-as.numeric(vapor_cat_post$X6M_QoL)
vapor_cat_post$X9M_QoL<-as.numeric(vapor_cat_post$X9M_QoL)
vapor_cat_post$X12M_QoL<-as.numeric(vapor_cat_post$X12M_QoL)
vapor_cat_post$X15M_QoL<-as.numeric(vapor_cat_post$X15M_QoL)
vapor_cat_post$X18M_QoL<-as.numeric(vapor_cat_post$X18M_QoL)
vapor_cat_post_QoL=t(vapor_cat_post)
vapor_cat_post_series_QoL=ts(vapor_cat_post_QoL, start=1,deltat=3)
matrix_series=matrix(NA,ncol=21)
matrix_series=cbind(t(vapor_num_post_series_qmax),t(vapor_num_post_series_ipss))
matrix_series=cbind(matrix_series,(t(vapor_cat_post_series_QoL)))


#On crée une matrice de dissimilarité utilisant la distance euclidienne
disMatrix=dist(matrix_series , method="euclidean")
#On fait une boucle pour repèrer les 5 meilleurs valeurs de k qui maximise la valeur silhouette
respam<- numeric(20)
for (k in 2:11)
respam[[k]] <- pam(disMatrix,k) $ silinfo $ avg.width
sortrespam=respam[which(respam>0.7)]
sortrespam=sort(sortrespam,decreasing=TRUE)
for (i in 1:5){
    if(i <= length(sortrespam))
    k.best[i] <-which(respam[]==sortrespam[i])
}
#On regarde le min de k pour une valeur silhouette supérieur à 0.7
k.min<-min(k.best)
cat("Les 5 meilleurs nombre de clusters sont", k.best, ".Ayant une valeur silhouette de ",respam[k.best[1]]," pour un nombre de cluster=" ,k.best[1]," . \n")
cat("Le nombre minimal de clusters pour une valeur silhouette supérieure à 0.7 est", k.min, " et ayant un valeur silhouette de ",respam[k.min],"\n")

k.optimal=k.min

resuhc <- hclust(disMatrix, method = "ward.D2")
# Visualization de resuhc
plot(resuhc, labels = FALSE, hang = -1)
# Ajout des rectangles autour des clusters
rect.hclust(resuhc, k = k.optimal, border = 2:4) 

k.optimal=6
plot(resuhc, labels = FALSE, hang = -1)
# Ajout des rectangles autour des clusters
rect.hclust(resuhc, k = k.optimal, border = 2:4) 

#Indication des médoids
medoid_post=c()
Q_max_medoids=matrix(NA)
Ipss_medoids=matrix(NA)
QoL_medoids=matrix(NA)
medoids_post=pam(disMatrix,k=k.optimal)$medoids
print(pam(disMatrix,k=k.optimal))
resdtw=matrix(NA)
for (i in 1:length(medoids_post)){
    medoid_post=rbind(medoid_post,vapor_post[medoids_post[i],])
    Q_max_medoid=vapor_num_post_series_qmax[,medoids_post[i]] 
    Ipss_medoid=vapor_num_post_series_ipss[,medoids_post[i]] 
    QoL_medoid=vapor_cat_post_series_QoL[,medoids_post[i]] 
    Q_max_medoids=cbind(Q_max_medoids,Q_max_medoid)
    Ipss_medoids=cbind(Ipss_medoids,Ipss_medoid)
    QoL_medoids=cbind(QoL_medoids,QoL_medoid)
}

ts.plot(Q_max_medoids,gpars= list(col=rainbow(6)),ylab= "Q_max",main="Représentation de l'évolution de Q_max pour différents individus")
legend("topright", c("Profil guérison type 1" ,"Profile guérison type 2","Profile guérison type 3","Profil guérison type 4","Profile guérison type 5","Profil guérison type 6"), col=rainbow(6), lty=1, cex=.65)
ts.plot(Ipss_medoids,gpars= list(col=rainbow(6)),ylab= "IPSS",main="Représentation de l'évolution de IPSS pour différents individus")
legend("topright", c("Profil guérison type 1" ,"Profile guérison type 2","Profile guérison type 3","Profil guérison type 4","Profile guérison type 5","Profil guérison type 6"), col=rainbow(6), lty=1, cex=.65)
ts.plot(QoL_medoids,gpars= list(col=rainbow(6)),ylab= "QoL",main="Représentation de l'évolution de QoL pour différents individus")
legend("topright", c("Profil guérison type 1" ,"Profile guérison type 2","Profile guérison type 3","Profil guérison type 4","Profile guérison type 5","Profil guérison type 6"), col=rainbow(6), lty=1, cex=.65)

respam=pam(disMatrix,k.optimal)
vapor_post_clus<-data.frame(vapor,respam$clustering)
class=c()  
for (i in 1:length(medoids_pre)){
    class=which(respam_optimal_pre$clustering==i)  
    class_guerison=vapor_post_clus$respam.clustering[class]
    df=data.frame(class_guerison)
    adenome_barplot(df,1,paste("Distribution des profils de guérison pour des profils de patients de la classe  ", i))
    }
# md[i]=which(vapor_post_clus$respam.clustering==medoids_pre[i])

matrix_for_tree_IPSS=matrix(NA)
ipss=subset(vapor_num_post,select=c(X12M_IPSS))
matrix_for_tree_IPSS=cbind(vapor_num_pre,ipss)
tree_IPSS=rpart(method="anova",formula=matrix_for_tree_IPSS$X12M_IPSS ~.,data=matrix_for_tree_IPSS,control=rpart.control(minsplit=5,cp=0))
pSimple_Ipss <- prune(tree_IPSS,cp=0)
rpart.plot(pSimple_Ipss)


# Evaluation de la performance de l'arbre avec 5 individus tirés au hasard
rnd_individus = sample(1:nrow(matrix_for_tree_IPSS),5)
df <- data.frame(round (predict(pSimple_Ipss,matrix_for_tree_IPSS[rnd_individus,])), matrix_for_tree_IPSS[rnd_individus,11])
colnames(df) <- c("Prédiction","Observé")
df

matrix_for_tree_Qmax=matrix(NA)
qmax=subset(vapor_num_post,select=c(X12M_Qmax))
matrix_for_tree_Qmax=cbind(vapor_num_pre,qmax)
tree_Qmax = rpart(method="anova",formula=matrix_for_tree_Qmax$X12M_Qmax ~ .,data=matrix_for_tree_Qmax,control=rpart.control(minsplit=5,cp=0))
pSimple_Qmax <- prune(tree_Qmax,cp=0)
rpart.plot(pSimple_Qmax)


# Evaluation de la performance de l'arbre avec 5 individus tirés au hasard
rnd_individus = sample(1:nrow(matrix_for_tree_Qmax),5)
df <- data.frame(predict(pSimple_Ipss,matrix_for_tree_Qmax[rnd_individus,]), matrix_for_tree_Qmax[rnd_individus,11])
colnames(df) <- c("Prédiction","Observé")
df

matrix_for_tree_QoL=matrix(NA)
qol=subset(vapor_cat_post,select=c(X12M_QoL))
matrix_for_tree_QoL=cbind(vapor_num_pre,qol)
tree_QoL = rpart(method="anova",formula=matrix_for_tree_QoL$X12M_QoL ~ .,data=matrix_for_tree_QoL,control=rpart.control(minsplit=6,cp=0))
pSimple_QoL <- prune(tree_QoL,cp=0)
rpart.plot(pSimple_QoL)

# Evaluation de la performance de l'arbre avec 5 individus tirés au hasard
rnd_individus = sample(1:nrow(matrix_for_tree_Qmax),5)
df <- data.frame(predict(pSimple_Ipss,matrix_for_tree_QoL[rnd_individus,]), matrix_for_tree_QoL[rnd_individus,11])
colnames(df) <- c("Prédiction","Observé")
df

vapor_pre_clus<-data.frame(vapor_pre,respam$clustering)
tree_cluster = rpart(method="anova",formula=vapor_pre_clus$respam.clustering~ .,data=vapor_pre_clus,control=rpart.control(minsplit=6,cp=0))
pSimple_clus <- prune(tree_cluster,cp=0)
rpart.plot(pSimple_clus)

# Evaluation de la performance de l'arbre avec 5 individus tirés au hasard
rnd_individus = sample(1:nrow(vapor_pre_clus),5)
df <- data.frame( round (predict(pSimple_Ipss,vapor_pre_clus[rnd_individus,])), vapor_pre_clus[rnd_individus,19])
colnames(df) <- c("Prédiction","Observé")
df
